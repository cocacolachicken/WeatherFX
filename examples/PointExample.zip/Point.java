import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Point {
    private double x;
    private double y;
    private double size = 5;

    public Point(double  xPos, double yPos) {
        x = xPos;
        y = yPos;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getWidth() { return size; }
    public double getHeight() { return size; }

    public void setX(double newX) { x = newX; }
    public void setY(double newY) { y = newY; }

    public void draw(GraphicsContext pen) {
        pen.setFill(Color.BLACK);
        pen.fillOval(x, y, size, size);
    }
}
