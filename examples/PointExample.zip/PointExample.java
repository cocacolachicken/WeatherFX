import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class PointExample extends ProcessingFX {
    Point p;

    public static void main(String[] args) {
        launch(args);
    }

    public void setup(GraphicsContext pen) {
        p = new Point(0, window.getHeight() / 2);
    }

    public void draw(GraphicsContext pen) {
        p.setX(p.getX() + 1);
        p.setY(p.getY() + Math.random()*5 - 2.5);
        //p.setY(mouse.getY());
        p.draw(pen);
        //System.out.println(key.getKeyCode() + " " + key.getKey());
    }
}
